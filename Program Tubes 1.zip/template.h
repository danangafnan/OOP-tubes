//File: Creation.h
#ifndef _CREATION_H
#define _creation_H

class creation{
	public:
		//ctor-dtor
		creation();
		~creation();
		
	private:
		
}

#endif _creation_H