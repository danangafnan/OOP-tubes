//File: Position.h
#ifndef _POSITION_H
#define _POSITION_H

class Position{ 
//Note: setelah dipikir-pikir jadi kayak point....apa jadi satu sama point 
//karena kan nanti ada point buat di bentuk-bentuk figure butuh point
	public:
		//ctor-dtor
		Position();
		~Position();
		
	private:
		double x;
		double y;
}

#endif _POSITION_H